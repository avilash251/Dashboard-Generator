# ws_registry.py placeholder
