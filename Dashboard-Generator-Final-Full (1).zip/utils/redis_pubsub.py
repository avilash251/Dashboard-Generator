import asyncio
import json
import redis.asyncio as redis

redis_client = redis.Redis(decode_responses=True)

REDIS_CHANNEL = "websocket_broadcast"

async def publish_to_redis(session_id: str, payload: dict):
    message = json.dumps({"session_id": session_id, "payload": payload})
    await redis_client.publish(REDIS_CHANNEL, message)

async def subscribe_to_redis(websocket_manager):
    pubsub = redis_client.pubsub()
    await pubsub.subscribe(REDIS_CHANNEL)
    print("📡 Redis Pub/Sub listener started...")

    async for message in pubsub.listen():
        if message is None or message.get("type") != "message":
            continue

        try:
            data = json.loads(message["data"])
            session_id = data.get("session_id")
            payload = data.get("payload")
            await websocket_manager.send_to_session(session_id, payload)
        except Exception as e:
            print(f"❌ Failed to parse redis message: {e}")