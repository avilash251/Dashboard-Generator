# followup_generator.py placeholder
