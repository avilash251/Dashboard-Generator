
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import time
import random

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class PromptRequest(BaseModel):
    prompt: str

@app.post("/api/query")
def query(req: PromptRequest):
    now = int(time.time())
    timestamps = [now - i * 60 for i in range(10)][::-1]

    def series(label, base):
        return {
            "metric": { "label": label },
            "values": [[ts, f"{base + random.uniform(-1, 1):.2f}"] for ts in timestamps]
        }

    return {
        "metadata": {
            "application": "App X",
            "clusters": 3,
            "nodes": 15,
            "services": 12,
            "tickets": 47,
            "datacenters": ["us-east-1", "ap-south-1"]
        },
        "panels": [
            { "title": "CPU Usage", "series": [series("CPU", 20)] },
            { "title": "Memory Usage", "series": [series("Memory", 500)] },
            { "title": "Network Bandwidth", "series": [series("Network", 100)] },
            { "title": "Redis Cache Hit Ratio", "series": [series("Redis", 98)] },
            { "title": "Ticket Volume", "series": [series("Tickets", 50)] },
            { "title": "Disk I/O", "series": [series("Disk", 300)] },
            { "title": "Latency", "series": [series("Latency", 100)] }
        ]
    }
