
import React, { useState } from "react";
import Highcharts from "highcharts";
import HighchartsReact from "highcharts-react-official";
import { DataGrid, GridColDef } from "@mui/x-data-grid";
import { Box, Button, Container, TextField, Typography, Paper } from "@mui/material";
import GridLayout from "react-grid-layout";
import "react-grid-layout/css/styles.css";
import "react-resizable/css/styles.css";

function App() {
  const [prompt, setPrompt] = useState("");
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState<any>(null);

  const handleQuery = async () => {
    setLoading(true);
    const res = await fetch("http://localhost:8000/api/query", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prompt })
    });
    const result = await res.json();
    setData(result);
    setLoading(false);
  };

  return (
    <Container maxWidth="xl" style={{ padding: "2rem" }}>
      <Typography variant="h4" gutterBottom>PromptQL Dashboard</Typography>

      <Box display="flex" gap={2} mb={4}>
        <TextField fullWidth label="Enter prompt..." value={prompt} onChange={(e) => setPrompt(e.target.value)} />
        <Button variant="contained" onClick={handleQuery} disabled={loading}>
          {loading ? "Loading..." : "Submit"}
        </Button>
      </Box>

      {data?.metadata && (
        <Paper sx={{ padding: 2, marginBottom: 4 }}>
          <Typography variant="h6">App Summary</Typography>
          <Box display="flex" gap={4} flexWrap="wrap" mt={2}>
            {Object.entries(data.metadata).map(([k, v]) => (
              <Box key={k}><b>{k}:</b> {Array.isArray(v) ? v.join(", ") : v}</Box>
            ))}
          </Box>
        </Paper>
      )}

      <GridLayout className="layout" cols={12} rowHeight={30} width={1200}>
        {data?.panels?.map((panel: any, idx: number) => (
          <div key={String(idx)} data-grid={{ i: String(idx), x: (idx % 2) * 6, y: Math.floor(idx / 2) * 6, w: 6, h: 6 }}>
            <Paper sx={{ padding: 2, height: "100%" }}>
              <Typography variant="subtitle1" gutterBottom>{panel.title}</Typography>
              <HighchartsReact
                highcharts={Highcharts}
                options={{
                  title: { text: undefined },
                  xAxis: { type: "datetime" },
                  series: panel.series.map((s: any) => ({
                    name: s.metric.label,
                    data: s.values.map(([x, y]: [number, string]) => [x * 1000, parseFloat(y)])
                  }))
                }}
              />
              <DataGrid
                autoHeight
                sx={{ marginTop: 2 }}
                columns={[
                  { field: 'timestamp', headerName: 'Timestamp', flex: 1 },
                  { field: 'value', headerName: 'Value', flex: 1 }
                ] as GridColDef[]}
                rows={panel.series[0].values.map(([ts, val]: [number, string], i: number) => ({
                  id: i,
                  timestamp: new Date(ts * 1000).toLocaleTimeString(),
                  value: val
                }))}
                pageSize={5}
                rowsPerPageOptions={[5]}
              />
            </Paper>
          </div>
        ))}
      </GridLayout>
    </Container>
  );
}

export default App;
